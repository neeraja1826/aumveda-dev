"""Admin dashboard schemas."""
