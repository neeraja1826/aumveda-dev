"""Admin customer schemas."""
