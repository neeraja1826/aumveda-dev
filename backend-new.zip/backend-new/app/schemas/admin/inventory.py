"""Admin inventory schemas."""
