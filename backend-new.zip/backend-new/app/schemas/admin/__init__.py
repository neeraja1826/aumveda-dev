"""Admin API schemas."""
