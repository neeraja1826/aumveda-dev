"""Admin category schemas."""
