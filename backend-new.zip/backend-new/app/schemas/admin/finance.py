"""Admin finance schemas."""
